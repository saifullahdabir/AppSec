// Vulnerable Entra SAML SP demo with HTTPS and OFF (disabled) signature/cert verification
// LAB USE ONLY — insecure by design

const fs = require('fs');
const https = require('https');
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const { Strategy: SamlStrategy } = require('@node-saml/passport-saml');
const xml2js = require('xml2js');
const fetch = require('node-fetch');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const selfsigned = require('selfsigned');
require('dotenv').config();

// === WARNING: GLOBAL TLS VERIFICATION DISABLED ===
// This makes outbound HTTPS requests accept any certificate (including self-signed).
// Lab-only!
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

// Create an https.Agent that will not verify TLS certs (for node-fetch calls)
const insecureAgent = new https.Agent({ rejectUnauthorized: false });

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'weak_session_secret',
  resave: true,
  saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());

const PORT = process.env.SERVER_PORT || 3000;
const ENTRY_POINT = process.env.SAML_ENTRY_POINT;
const ISSUER = process.env.SAML_ISSUER;
const CALLBACK_URL = process.env.SAML_CALLBACK_URL;
const JWT_SECRET = process.env.JWT_SECRET || 'very_weak_jwt_secret';
const REDIRECT_AFTER_LOGIN_URL = process.env.REDIRECT_AFTER_LOGIN_URL || '/home';

// Generate self-signed certificate if missing (for HTTPS)
let keyPath = './vulnerable.local.key';
let certPath = './vulnerable.local.crt';

if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
  console.log('Generating self-signed HTTPS certificate...');
  const attrs = [{ name: 'commonName', value: 'vulnerable.local' }];
  const pems = selfsigned.generate(attrs, { days: 365, keySize: 2048 });
  fs.writeFileSync(keyPath, pems.private);
  fs.writeFileSync(certPath, pems.cert);
}

// Load server certificate/key for HTTPS
const httpsOptions = {
  key: fs.readFileSync(keyPath),
  cert: fs.readFileSync(certPath)
};

// Load IdP certificate if present (we will not enforce it)
let idpCert = null;
try {
  idpCert = fs.readFileSync(process.env.SAML_CERT_PATH, 'utf8');
  console.warn('Loaded IdP certificate but signature checks are disabled (lab mode).');
} catch (e) {
  console.warn('No IdP cert found — continuing without one (lab vulnerable).');
  idpCert = null;
}

// Passport serialize/deserialize
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

// ======= SAML STRATEGY (INTENTIONALLY INSECURE) =======
// We explicitly disable signature and related checks so the SP will accept unsigned/forged responses.
// These options are dangerous and for testing only.
passport.use(new SamlStrategy(
  {
    entryPoint: ENTRY_POINT,
    issuer: ISSUER,
    callbackUrl: CALLBACK_URL,
    // leave cert null or set to idpCert — in either case we will NOT enforce signature checks below
    cert: idpCert,
    // ********** LAB-INSECURE FLAGS **********
    // Do NOT require signed assertions or signed responses
    wantAssertionsSigned: true,
    wantAuthnResponseSigned: false,
    // Disable InResponseTo validation (replay protection)
    validateInResponseTo: true,
    // Make the library permissive about requested authn context
    disableRequestedAuthnContext: true,
    // Allow larger clock skew to avoid timestamp issues in lab
    acceptedClockSkewMs: 300000
  },
  // Note: this verify callback trusts the profile as-is (INSECURE)
  (profile, done) => {
    // Normalize a minimal user object
    const user = {
      nameID: profile.nameID || profile['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier'] || 'unknown',
      email: profile['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress'] || profile.email || null,
      raw: profile
    };
    return done(null, user);
  }
));

// Routes
app.get('/', (req, res) => {
  res.send(`<h1>Vulnerable Entra SAML Demo (Lab)</h1>
            <p><a href='/api/auth/login'>Login with Entra (SAML)</a></p>
            <p>ACS: ${CALLBACK_URL || 'not configured'}</p>`);
});

// Login redirect to IdP
app.get('/api/auth/login',
  passport.authenticate('saml', { failureRedirect: '/' }),
  (req, res) => res.redirect('/')
);

// SAML callback (ACS) - vulnerable because signature checks disabled
app.post('/api/auth/callback',
  passport.authenticate('saml', { failureRedirect: '/' }),
  (req, res) => {
    const user = req.user;
    const token = jwt.sign(
      { sub: user.nameID || 'unknown', attrs: user.raw || {} },
      JWT_SECRET,
      { expiresIn: '30d' }
    );
    // Intentionally not HttpOnly to make token accessible to client-side JS (lab-only vulnerability)
    res.cookie('auth_token', token, { httpOnly: false });
    res.redirect(REDIRECT_AFTER_LOGIN_URL);
  }
);

// Protected route
app.get('/api/protected', (req, res) => {
  const token = req.cookies?.auth_token;
  if (!token) return res.status(401).send('No token');

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    res.send(`<h3>Welcome ${payload.sub}</h3><pre>${JSON.stringify(payload, null, 2)}</pre>`);
  } catch (e) {
    res.status(401).send('Invalid token');
  }
});

// Vulnerable SSRF / metadata fetch demo (uses insecure TLS agent)
app.post('/api/fetch-metadata', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).send('missing url');
  try {
    // use insecureAgent so self-signed / invalid certificates won't block fetch
    const resp = await fetch(url, { agent: insecureAgent });
    const body = await resp.text();
    fs.writeFileSync('./fetched_metadata.xml', body);
    res.send('fetched');
  } catch (err) {
    console.error(err);
    res.status(500).send('fail');
  }
});

// Logout
app.get('/api/logout', (req, res) => {
  res.clearCookie('auth_token');
  req.logout(() => {});
  res.redirect('/');
});

// Start HTTPS server
https.createServer(httpsOptions, app).listen(PORT, () => {
  console.log(`HTTPS vulnerable.local running on https://vulnerable.local:${PORT}`);
  console.log('NOTE: TLS cert verification and SAML signature validation are disabled (lab mode).');
});
