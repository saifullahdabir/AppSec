const selfsigned = require('selfsigned');
const fs = require('fs');

const attrs = [{ name: 'commonName', value: 'vulnerable.local' }];
const opts = { days: 365, keySize: 2048, algorithm: 'sha256' };

const pems = selfsigned.generate(attrs, opts);

fs.writeFileSync('vulnerable.local.key', pems.private);
fs.writeFileSync('vulnerable.local.crt', pems.cert);

console.log('Self-signed certificate generated: vulnerable.local.key & vulnerable.local.crt');
