// Vulnerable Entra SAML SP demo with HTTPS and proper flow
// Lab purpose only

const fs = require('fs');
const https = require('https');
const express = require('express');
const bodyParser = require('body-parser');
const session = require('express-session');
const passport = require('passport');
const { Strategy: SamlStrategy } = require('@node-saml/passport-saml');
const xml2js = require('xml2js');
const fetch = require('node-fetch');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const selfsigned = require('selfsigned');
require('dotenv').config();

const app = express();

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'weak_session_secret',
  resave: true,
  saveUninitialized: true
}));
app.use(passport.initialize());
app.use(passport.session());

const PORT = process.env.SERVER_PORT || 3000;
const ENTRY_POINT = process.env.SAML_ENTRY_POINT;
const ISSUER = process.env.SAML_ISSUER;
const CALLBACK_URL = process.env.SAML_CALLBACK_URL;
const JWT_SECRET = process.env.JWT_SECRET || 'very_weak_jwt_secret';
const REDIRECT_AFTER_LOGIN_URL = process.env.REDIRECT_AFTER_LOGIN_URL || '/home';

// Generate self-signed certificate if missing
let keyPath = './vulnerable.local.key';
let certPath = './vulnerable.local.crt';

if (!fs.existsSync(keyPath) || !fs.existsSync(certPath)) {
  console.log('Generating self-signed HTTPS certificate...');
  const attrs = [{ name: 'commonName', value: 'vulnerable.local' }];
  const pems = selfsigned.generate(attrs, { days: 365, keySize: 2048 });
  fs.writeFileSync(keyPath, pems.private);
  fs.writeFileSync(certPath, pems.cert);
}

// Load certificate
const httpsOptions = {
  key: fs.readFileSync(keyPath),
  cert: fs.readFileSync(certPath)
};

// Load IdP certificate
let idpCert = '';
try {
  idpCert = fs.readFileSync(process.env.SAML_CERT_PATH, 'utf8');
} catch (e) {
  console.warn('No IdP cert found — continuing with dummy cert (lab vulnerable)');
  idpCert = 'dummy-cert';
}

// Passport serialize/deserialize
passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((obj, done) => done(null, obj));

// Configure SAML strategy
passport.use(new SamlStrategy(
  {
    entryPoint: ENTRY_POINT,
    issuer: ISSUER,
    callbackUrl: CALLBACK_URL,
    cert: idpCert,
    validateInResponseTo: true,        // disables replay protection
    disableRequestedAuthnContext: true,
    acceptedClockSkewMs: 300000,
    verifySignature: false               // proper verification with IdP cert
  },
  (profile, done) => {
    return done(null, profile);
  }
));

// Routes
app.get('/', (req, res) => {
  res.send(`<h1>Vulnerable Entra SAML Demo</h1>
            <a href='/api/auth/login'>Login with Entra (SAML)</a>`);
});

// Login redirect to IdP
app.get('/api/auth/login',
  passport.authenticate('saml', { failureRedirect: '/' }),
  (req, res) => res.redirect('/')
);

// SAML callback
app.post('/api/auth/callback',
  passport.authenticate('saml', { failureRedirect: '/' }),
  (req, res) => {
    // Successful authentication
    const user = req.user;
    const token = jwt.sign(
      { sub: user.nameID || 'unknown', attrs: user },
      JWT_SECRET,
      { expiresIn: '30d' }
    );
    res.cookie('auth_token', token, { httpOnly: false }); // vulnerable: httpOnly false
    res.redirect(REDIRECT_AFTER_LOGIN_URL);
  }
);

// Protected route
app.get('/api/protected', (req, res) => {
  const token = req.cookies?.auth_token;
  if (!token) return res.status(401).send('No token');

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    res.send(`<h3>Welcome ${payload.sub}</h3><pre>${JSON.stringify(payload, null, 2)}</pre>`);
  } catch (e) {
    res.status(401).send('Invalid token');
  }
});

// Vulnerable SSRF / fetch demo
app.post('/api/fetch-metadata', async (req, res) => {
  const { url } = req.body;
  if (!url) return res.status(400).send('missing url');
  try {
    const resp = await fetch(url);
    const body = await resp.text();
    fs.writeFileSync('./fetched_metadata.xml', body);
    res.send('fetched');
  } catch (err) {
    res.status(500).send('fail');
  }
});

// Logout
app.get('/api/logout', (req, res) => {
  res.clearCookie('auth_token');
  req.logout(() => {});
  res.redirect('/');
});

// Start HTTPS server
https.createServer(httpsOptions, app).listen(PORT, () => {
  console.log(`HTTPS vulnerable.local running on https://vulnerable.local:${PORT}`);
});
